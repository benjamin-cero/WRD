let globalPodaci = [];
let k1_preuzmi = () => {
  //od 22.06.2025. koristi se adresa servera "wrd-api.fit.ba" umjesto "wrd-fit.info"
  fetch(`https://wrd-api.fit.ba/Ispit20250621/GetNovePonude`).then((res) => {
    res.json().then((body) => {
      globalPodaci = body.podaci;
      for (let i = 0; i < globalPodaci.length; i++) {
        document.getElementById("destinacije").innerHTML += `
                <div class="best-offer-wrapper">
              <div class="offer-akcija">${globalPodaci[i].akcijaPoruka}</div>
              <div class="best-offer">
                <div class="offer-header">
                  <img src="${globalPodaci[i].slikaUrl}"/>
                </div>
                <div class="offer-content-wrapper">
                <div class="offer-content">
                  <h2>${globalPodaci[i].drzava}</h2>
                  <p>${globalPodaci[i].opisPonude}</p>
                  <div class="offer-date">
                    <div>Datum polaska:</div>
                    <div>${globalPodaci[i].naredniPolazak.datumPol}</div>
                  </div>
                  <div class="offer-price">
                    <div>Cijena:</div>
                    <div>${globalPodaci[i].naredniPolazak.cijenaPoOsobiEur}$</div>
                  </div>
                </div>
                <div class="offer-button" onclick="k2_odaberiDestinaciju(${i})">K2 Odaberi ponudu</div>
                </div>
              </div>
            </div>`;
      }
      console.log(body);
    });
  });
};
k1_preuzmi();

let k2_odaberiDestinaciju = (rb) => {
  let nizPutovanja = globalPodaci[rb].planiranaPutovanja;
  document.getElementById("destinacija").value = globalPodaci[rb].drzava;
  document.getElementById("putovanjaTabela").innerHTML = "";
  for (let i = 0; i < nizPutovanja.length; i++) {
    document.getElementById("putovanjaTabela").innerHTML += `
    <tr class="putovanje-red" id="putovanje-red-${i}" draggable="true">
      <td>${nizPutovanja[i].idPutovanje}</td>
      <td>${nizPutovanja[i].datumPol}</td>
      <td>${nizPutovanja[i].datumPov}</td>
      <td>${nizPutovanja[i].countSlobodnoMjesta}</td>
      <td>${nizPutovanja[i].cijenaPoOsobiEur}</td>
      <td><button onclick="k3_odaberiPutovanje()">K3 Odaberi</button></td>
    </tr>
    `;
  }
};

let k3_odaberiPutovanje = () => {};

let ErrorBackgroundColor = "#FE7D7D";
let OkBackgroundColor = "#DFF6D8";

let k4_promjenaBrojaGostiju = () => {};

let k5_posalji = () => {
  //https://wrd-api.fit.ba/ -> Ispit20250621 -> Add

  /*if (!provjeriPrimjer()) {
    messageSuccess("Neka greška");
    return;
  }*/

  //od 22.06.2025. koristi se adresa servera "wrd-api.fit.ba" umjesto "wrd-fit.info"
  fetch("https://wrd-api.fit.ba/Ispit20250621/Dodaj", {
    method: "POST",
    body: "{}", //ovdje postaviti body
    headers: {
      "Content-Type": "application/json",
    },
  }).then((res) => {
    res.json().then((body) => {
      dialogSuccess(
        "Uspješno kreirana rezervacija sa brojem : " + body.idRezervacije
      );
    });
  });
};

let provjeriPasos = () => {};
let provjeriEmail = () => {};

let provjeriPrimjer = () => {
  //ovo treba obrisati
  if (!/^IB[0-9]{6}$/.test(document.getElementById("brojPasosa").value)) {
    document.getElementById("brojPasosa").style.backgroundColor =
      ErrorBackgroundColor;
    return false;
  } else {
    document.getElementById("brojPasosa").style.backgroundColor =
      OkBackgroundColor;
    return true;
  }
};
