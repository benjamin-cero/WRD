/* -------------------------------------------------------------------------- */
/* API putanje su pripremljene                                                 */
/* -------------------------------------------------------------------------- */

const API_PONUDE = "https://wrd-api.fit.ba/Ispit20250712/GetNovePonude";
const API_REZERVACIJE = "https://wrd-api.fit.ba/Ispit20250712/Dodaj";

let globalPodaci = [];
let odabranoPutovanje = null;

const ErrorBackgroundColor = "#FE7D7D";
const OkBackgroundColor = "#DFF6D8";

/* -------------------------------------------------------------------------- */
/* Pripremljene poruke                                                         */
/* -------------------------------------------------------------------------- */

function prikaziPoruku(tip, naslov, tekst, trajanje = 5500) {
  let container = document.getElementById("app-poruke");

  if (!container) {
    container = document.createElement("div");
    container.id = "app-poruke";
    container.className = "app-messages";
    container.setAttribute("aria-live", "polite");
    document.body.appendChild(container);
  }

  const poruka = document.createElement("div");
  poruka.className = `app-message app-message-${tip}`;
  poruka.innerHTML = `
    <div>
      <strong>${naslov}</strong>
      <p>${tekst}</p>
    </div>
    <button type="button" aria-label="Zatvori poruku">×</button>
  `;

  function ukloniPoruku() {
    poruka.classList.add("is-hiding");
    window.setTimeout(function () {
      poruka.remove();
    }, 220);
  }

  poruka.querySelector("button").addEventListener("click", ukloniPoruku);
  container.appendChild(poruka);

  if (trajanje > 0) window.setTimeout(ukloniPoruku, trajanje);
}

function messageDanger(htmlPoruka) {
  prikaziPoruku("error", "Greška", htmlPoruka);
}

function dialogSuccess(htmlPoruka) {
  prikaziPoruku("success", "Rezervacija je evidentirana", htmlPoruka, 7500);
}

function postaviApiPoruku(html) {
  if (document.getElementById("poruke")) {
    document.getElementById("poruke").innerHTML = html;
  }
}

/* -------------------------------------------------------------------------- */
/* Pripremljeno: preuzimanje i osnovni prikaz ponuda                          */
/* -------------------------------------------------------------------------- */

async function k1_preuzmi() {
  const destinacije = document.getElementById("destinacije");
  if (!destinacije) return;

  globalPodaci = [];
  odabranoPutovanje = null;
  postaviApiPoruku("");

  destinacije.innerHTML = `
    <div class="loading-card">
      <span class="loading-spinner" aria-hidden="true"></span>
      <div>
        <strong>Učitavanje ponuda...</strong>
        <p>Podaci se preuzimaju sa WRD API-ja.</p>
      </div>
    </div>
  `;

  try {
    const odgovor = await fetch(API_PONUDE, { cache: "no-store" });
    if (!odgovor.ok) throw new Error(`API status ${odgovor.status}`);

    const body = await odgovor.json();
    globalPodaci = Array.isArray(body.podaci) ? body.podaci : [];

    if (globalPodaci.length === 0) {
      destinacije.innerHTML = `
        <div class="empty-state">
          <strong>Trenutno nema dostupnih ponuda.</strong>
          <p>API nije vratio nijednu destinaciju.</p>
        </div>
      `;
      return;
    }

    prikaziDestinacije(globalPodaci);
    azurirajBrojRezultata(globalPodaci.length);
    postaviApiPoruku(`
      <div class="api-status api-status-success">
        <span></span>
        Učitano je ${globalPodaci.length} ponuda sa API-ja.
      </div>
    `);
  } catch (greska) {
    console.error("Greška pri preuzimanju ponuda:", greska);
    destinacije.innerHTML = `
      <div class="empty-state error-state">
        <strong>Ponude nisu učitane.</strong>
        <p>Provjeri internet konekciju i pokreni stranicu preko Live Servera.</p>
        <button type="button" onclick="k1_preuzmi()">Pokušaj ponovo</button>
      </div>
    `;
    postaviApiPoruku(
      '<div class="api-status api-status-error">API trenutno nije dostupan.</div>',
    );
    messageDanger("Greška pri učitavanju ponuda sa API-ja.");
  }
}

function prikaziDestinacije(podaci) {
  const destinacije = document.getElementById("destinacije");
  if (!destinacije) return;

  if (!Array.isArray(podaci) || podaci.length === 0) {
    destinacije.innerHTML = `
      <div class="empty-state">
        <strong>Nema ponuda koje odgovaraju pretrazi.</strong>
        <p>Promijeni tekstualni pojam ili minimalan broj noćenja.</p>
      </div>
    `;
    return;
  }

  destinacije.innerHTML = podaci
    .map(function (ponuda) {
      const originalIndex = globalPodaci.indexOf(ponuda);
      const naredniPolazak = ponuda.naredniPolazak || {};
      const gradovi = Array.isArray(ponuda.boravakGradovi)
        ? ponuda.boravakGradovi
        : [];

      let ukupnoNocenja = 0;
      let gradoviHtml = "";

      for (let i = 0; i < gradovi.length; i++) {
        ukupnoNocenja += Number(gradovi[i].brojNocenja);
        gradoviHtml += `
          <span class="city-chip">
            ${gradovi[i].nazivGrada} · ${gradovi[i].brojNocenja} noći
          </span>
        `;
      }

      const akcijaHtml = ponuda.akcijaPoruka
        ? `<span class="offer-sale">${ponuda.akcijaPoruka}</span>`
        : "";

      return `
        <article class="destination-card" data-destination-index="${originalIndex}">
          <div class="destination-image-wrap">
            <img
              src="${ponuda.slikaUrl}"
              alt="${ponuda.drzava}"
              loading="lazy"
              onerror="this.closest('.destination-image-wrap').classList.add('image-error'); this.remove();"
            />
            ${akcijaHtml}
          </div>

          <div class="destination-content">
            <div class="destination-title-row">
              <div>
                <span class="destination-kicker">Ponuda #${ponuda.id}</span>
                <h3>${ponuda.drzava}</h3>
              </div>
              <span class="destination-arrow">↗</span>
            </div>

            <p class="destination-description">${ponuda.opisPonude}</p>
            <div class="offer-cities">${gradoviHtml}</div>

            <div class="offer-info-grid four-items">
              <div>
                <span>Polazak</span>
                <strong>${naredniPolazak.datumPol || "Nije objavljeno"}</strong>
              </div>
              <div>
                <span>Slobodna mjesta</span>
                <strong>${naredniPolazak.countSlobodnoMjesta ?? 0}</strong>
              </div>
              <div>
                <span>Ukupno noćenja</span>
                <strong>${ukupnoNocenja}</strong>
              </div>
              <div>
                <span>Cijena po osobi</span>
                <strong>${Number(naredniPolazak.cijenaPoOsobiEur).toFixed(2)} €</strong>
              </div>
            </div>

            <button
              class="choose-offer-button"
              type="button"
              onclick="k2_odaberiDestinaciju(${originalIndex})"
            >
              Prikaži termine
              <span>→</span>
            </button>
          </div>
        </article>
      `;
    })
    .join("");
}

/* -------------------------------------------------------------------------- */
/* Z1 — filtriranje ponuda                                                     */
/* -------------------------------------------------------------------------- */

function primijeniFiltere() {
  // TODO Z1:
  // - tekstualna pretraga po državi, gradu ili opisu;
  // - minimalan ukupan broj noćenja;
  // - kombinovati oba filtera;
  // - osvježiti kartice i broj rezultata.
}

function azurirajBrojRezultata(broj) {
  // TODO Z1: prikazati broj rezultata u elementu #rezultatiBroj.
}

/* -------------------------------------------------------------------------- */
/* Pripremljeno: osnovni prikaz termina                                        */
/* -------------------------------------------------------------------------- */

function k2_odaberiDestinaciju(indexPonude) {
  const ponuda = globalPodaci[indexPonude];
  const tabela = document.getElementById("putovanjaTabela");

  if (!ponuda || !tabela) {
    messageDanger("Odabrana ponuda nije pronađena.");
    return;
  }

  odabranoPutovanje = null;

  document.querySelectorAll(".destination-card").forEach(function (kartica) {
    kartica.classList.remove("selected-card");
  });
  document
    .querySelector(`[data-destination-index="${indexPonude}"]`)
    ?.classList.add("selected-card");

  document.getElementById("brojOdraslih").value = "";
  document.getElementById("brojDjece").value = "0";
  document.getElementById("ukupnoPutnika").value = "";
  document.getElementById("ukupnaCijena").value = "";
  document.getElementById("gosti").innerHTML =
    '<div class="guest-info">Odaberi termin, zatim unesi broj odraslih i djece.</div>';

  const putovanja = Array.isArray(ponuda.planiranaPutovanja)
    ? ponuda.planiranaPutovanja
    : [];

  if (putovanja.length === 0) {
    tabela.innerHTML =
      '<tr><td colspan="7">Za ovu destinaciju nema planiranih putovanja.</td></tr>';
    return;
  }

  tabela.innerHTML = putovanja
    .map(function (putovanje, indexPutovanja) {
      const slobodnaMjesta = Number(putovanje.countSlobodnoMjesta);
      const popunjeno = slobodnaMjesta <= 0;

      return `
        <tr id="putovanje-red-${indexPutovanja}">
          <td><strong>#${putovanje.idPutovanje}</strong></td>
          <td>${putovanje.datumPol}</td>
          <td>${putovanje.datumPov}</td>
          <td>—</td>
          <td>
            <span class="seats-badge ${popunjeno ? "sold-out" : ""}">
              ${slobodnaMjesta}
            </span>
          </td>
          <td><strong>${Number(putovanje.cijenaPoOsobiEur).toFixed(2)} €</strong></td>
          <td>
            <button
              type="button"
              ${popunjeno ? "disabled" : ""}
              onclick="k3_odaberiPutovanje(${indexPonude}, ${indexPutovanja})"
            >${popunjeno ? "Popunjeno" : "Odaberi"}</button>
          </td>
        </tr>
      `;
    })
    .join("");

}

/* -------------------------------------------------------------------------- */
/* Z2 — trajanje i odabir termina                                              */
/* -------------------------------------------------------------------------- */

function k3_odaberiPutovanje(indexPonude, indexPutovanja) {
  // TODO Z2:
  // - sačuvati odabrano putovanje u globalnu varijablu odabranoPutovanje;
  // - označiti samo trenutno odabrani red;
  // - ukloniti marker sa prethodno odabranog reda.
  //
  // Izračun trajanja u danima dodati u funkciju za prikaz termina.
}

/* -------------------------------------------------------------------------- */
/* Z3 — odrasli, djeca, dinamička polja i cijena                              */
/* -------------------------------------------------------------------------- */

function k4_promjenaPutnika() {
  // TODO Z3:
  // - provjeriti broj odraslih i djece prema pravilima zadatka;
  // - generisati polja za ime i prezime svakog putnika;
  // - sačuvati ranije unesena imena za polja koja i dalje postoje;
  // - vizuelno razlikovati odrasle i djecu;
  // - izračunati i prikazati ukupnu cijenu rezervacije.
}

function provjeriBrojPutnika() {
  // TODO Z3/Z5: vratiti prazan string kada su brojevi ispravni,
  // a tekst greške kada nisu ispravni.
  return "";
}

/* -------------------------------------------------------------------------- */
/* Z4 — frontend validacija                                                    */
/* -------------------------------------------------------------------------- */

function provjeriPasos() {
  // TODO Z4: validacija identifikacionog dokumenta i bojenje polja.
  return "";
}

function provjeriEmail() {
  // TODO Z4: validacija email adrese i bojenje polja.
  return "";
}

// DODANO U VERZIJI ZA VJEŽBU — ovaj primjer nije bio u starter projektu
// korištenom na ispitu 15.07.2026. Primjer pokazuje upotrebu regexa i .test().
//
// function provjeriBrojTelefona() {
//   let phone = document.getElementById("phone");
//
//   if (!/^\+387 6[0-9] \d{3} \d{3}$/.test(phone.value)) {
//     phone.style.backgroundColor = ErrorBackgroundColor;
//     return "Telefon mora biti u formatu: +387 61 123 456\n";
//   } else {
//     phone.style.backgroundColor = OkBackgroundColor;
//     return "";
//   }
// }

/* -------------------------------------------------------------------------- */
/* Z5 — kreiranje objekta i slanje rezervacije                                */
/* -------------------------------------------------------------------------- */

function kreirajObjekatRezervacije() {
  // TODO Z5: kreirati objekat prema Swagger shemi Ispit20250712DodajRequest
  // i dodati tražene dodatne frontend podatke.
  return {};
}

function k5_posalji() {
  let frontendGreskeValidacije = "";

  // TODO Z5:
  // - pozvati sve frontend validacije;
  // - spojiti njihove poruke u frontendGreskeValidacije;
  // - blokirati POST ako postoji barem jedna greška.

  if (frontendGreskeValidacije !== "") {
    messageDanger(
      "Frontend validacija:<br><br>" +
        frontendGreskeValidacije.replace(/\n/g, "<br>"),
    );
    return;
  }

  const jsObjekat = kreirajObjekatRezervacije();

  fetch(API_REZERVACIJE, {
    method: "POST",
    body: JSON.stringify(jsObjekat),
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then(function (res) {
      return res.json();
    })
    .then(function (body) {
      if (body.brojGresaka === 0) {
        dialogSuccess(
          "Uspješno kreirana rezervacija sa brojem: " + body.idRezervacije,
        );
      } else {
        const backendGreskeValidacije = Array.isArray(body.spisakGresaka)
          ? body.spisakGresaka.join("<br>")
          : "API je odbio poslane podatke.";

        messageDanger(
          "Backend validacija: Poslati JSON podaci nisu ispravni.<br><br>" +
            backendGreskeValidacije,
        );
      }
    })
    .catch(function () {
      messageDanger("Greška pri slanju rezervacije.");
    });
}

document.addEventListener("DOMContentLoaded", k1_preuzmi);
